from quickspacer import Spacer
import pandas as pd
spacer = Spacer()

# spaincg 된 nsmc 데이터셋을 만듭니다.

file_list = ['ratings_dev.tsv', 'ratings_test.tsv', 'ratings_train.tsv']

for file_path in file_list:

    sentences = []
    labels = []
    with open(file_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f.readlines()[1:]):
            splitted = line.strip().split("\t")
            if len(splitted) != 2:
                #print(f"[ERROR] {repr(line)}, line {i}")
                continue

            splitted[0] = spacer.space([splitted[0]])[0]
            sentences.append(splitted[0])            
            labels.append(splitted[1])
            
    # write
    data = pd.DataFrame({'document':sentences,
                         'label':labels})

    data.to_csv('spaced_'+file_path, sep='\t', index=False)

