#! /usr/bin/python3
# -*- coding: utf-8 -*-

import numpy as np; np.random.seed(1234)
import pandas as pd

# train set에서 10%을 떼내어 dev set을 만듭니다.
train_data = pd.read_csv('./ratings_train.txt', sep='\t', quoting=3)

ntrain = len(train_data)
ndev = round(ntrain * 0.1)

data = pd.read_csv('./ratings_train.txt', sep='\t', quoting=3)
data = pd.DataFrame(np.random.permutation(data))
dev, trn = data[:ndev], data[ndev:]

header = 'id document label'.split()
trn.to_csv('./ratings_train.txt', sep='\t', index=False, header=header)
dev.to_csv('./ratings_dev.txt', sep='\t', index=False, header=header)

