import random

with open('ratings_train.txt', 'r', encoding='utf-8') as r:
    total = r.readlines()    
 
txt = total[15000:]  
dev = total[1:15000]

    

print(len(txt))
print(len(dev))


with open('ratings_train2.txt', 'w', encoding='utf-8') as f:
    for line in txt:    
        f.write(line)

with open('ratings_dev.txt', 'w', encoding='utf-8') as f:
    for line in dev:
        f.write(line)
