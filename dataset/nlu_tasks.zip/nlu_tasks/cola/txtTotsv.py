import csv
from io import StringIO

lists = ['cola_test.txt']


for txt in lists:
    with open(txt, encoding='utf-8') as f_predictions, open(txt[:-4]+'.tsv', 'w', newline='', encoding='utf-8') as f_output:
        csv_output = csv.writer(f_output, delimiter='\t')
        #csv_output.writerow(['id', 'document', 'label'])
        for line in f_predictions:
            row = next(csv.reader(StringIO(line), delimiter='\t', skipinitialspace=True))
            csv_output.writerow([row[0], row[1]])
