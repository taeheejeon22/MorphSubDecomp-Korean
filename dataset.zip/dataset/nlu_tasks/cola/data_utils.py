sentences = []
labels = []

with open('cola_train.tsv', "r", encoding="utf-8") as f:
    for i, line in enumerate(f.readlines()):
        splitted = line.strip().split("\t")
        if len(splitted) != 2:
            print(line, i)
            continue
        print(splitted[0], splitted[1])
        sentences.append(splitted[0])
        labels.append(splitted[1])


print(len(sentences))
print(len(labels))
