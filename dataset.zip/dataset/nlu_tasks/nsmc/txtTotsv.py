import csv
from io import StringIO

lists = ['ratings_train2.txt', 'ratings_dev.txt', 'ratings_test.txt']


for txt in lists:
    with open(txt) as f_predictions, open(txt[:-4]+'.tsv', 'w', newline='') as f_output:
        csv_output = csv.writer(f_output, delimiter='\t')
        #csv_output.writerow(['id', 'document', 'label'])
        for line in f_predictions:
            row = next(csv.reader(StringIO(line), delimiter='\t', skipinitialspace=True))
            if len(row) == 3:
                csv_output.writerow([row[1], row[2]])
